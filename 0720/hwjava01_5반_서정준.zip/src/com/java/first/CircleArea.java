package com.java.first;

public class CircleArea {
	public static void main(String[] args) {
		// 반지름이 5cm인 원의 넓이를 출력
		int radius = 5;
		double area = (double)radius * radius * 3.14;
		System.out.println("반지름이 "+radius+"Cm인 원의 넓이는 "+area+"Cm2입니다.");
	}
}  	
